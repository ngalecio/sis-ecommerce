export {};
//# sourceMappingURL=wrapped-select.test.d.ts.map